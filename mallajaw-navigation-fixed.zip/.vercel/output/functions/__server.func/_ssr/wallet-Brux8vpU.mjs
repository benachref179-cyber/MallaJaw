import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Y as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { S as cn, _ as SCRATCH_CARDS, d as balanceOf, f as useMj, g as OPERATORS, l as Page, m as COUNTRIES, o as Button, s as Franc, v as clock } from "./router-DYxSR_8k.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/wallet-Brux8vpU.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function groupPin(value) {
	return value.replace(/\D/g, "").slice(0, 14).replace(/(\d{4})(?=\d)/g, "$1 ").trim();
}
function WalletPage() {
	const profileCountry = useMj((state) => state.profile.country);
	const ledger = useMj((state) => state.ledger);
	const usedCodes = useMj((state) => state.usedCodes);
	const redeem = useMj((state) => state.redeem);
	const balance = balanceOf(ledger);
	const [country, setCountry] = (0, import_react.useState)(profileCountry);
	const [operator, setOperator] = (0, import_react.useState)("orange");
	const [pin, setPin] = (0, import_react.useState)("");
	const [message, setMessage] = (0, import_react.useState)("");
	const [ok, setOk] = (0, import_react.useState)(false);
	const cards = (0, import_react.useMemo)(() => SCRATCH_CARDS.filter((card) => card.country === country && card.operator === operator), [country, operator]);
	function submit(code) {
		const result = redeem(code);
		if (result.ok) {
			setOk(true);
			setMessage(`تمت إضافة ${new Intl.NumberFormat("fr-FR").format(result.francs)} فرنك. البطاقة ما تخصمش هاتفك الحقيقي.`);
			setPin("");
		} else {
			setOk(false);
			setMessage(result.reason);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
		title: "المحفظة",
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Franc, {
			value: balance,
			className: "text-lg font-extrabold"
		}),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-4 text-sm text-muted",
				children: "الشحن تجريبي داخل ملا جو. الرمز يضيف فرنكات هنا ولا يُرسل إلى أورونج أو أوريدو أو تيليكوم، ولا يُخصم من رصيد الخط."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-3 grid grid-cols-3 gap-2",
				children: COUNTRIES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setCountry(item.id),
					className: cn("min-h-11 rounded-xl border text-sm font-bold", country === item.id ? "border-accent bg-panel-2 text-ink" : "border-line bg-panel text-muted"),
					children: item.name
				}, item.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-4 grid grid-cols-3 gap-2",
				children: OPERATORS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setOperator(item.id),
					className: cn("min-h-11 rounded-xl border px-2 text-sm font-bold", operator === item.id ? "border-accent bg-panel-2 text-ink" : "border-line bg-panel text-muted"),
					children: item.name
				}, item.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mb-4 flex flex-col gap-2",
				children: cards.map((card) => {
					const used = usedCodes.includes(card.code);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						disabled: used,
						onClick: () => {
							setPin(groupPin(card.code));
							setMessage("");
						},
						className: "flex w-full items-center justify-between rounded-card border border-line bg-panel px-4 py-3 text-start disabled:opacity-40",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-extrabold",
							children: card.face
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-muted",
							children: used ? "استُعملت" : "بطاقة تجريبية — اضغط لتعبئة الرمز"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Franc, {
							value: card.francs,
							className: "font-bold"
						})]
					}) }, card.code);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "rounded-card border border-line bg-panel p-4",
				onSubmit: (event) => {
					event.preventDefault();
					submit(pin);
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						htmlFor: "pin",
						className: "text-sm font-bold",
						children: "رمز البطاقة"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "pin",
						value: pin,
						onChange: (event) => setPin(groupPin(event.target.value)),
						inputMode: "numeric",
						autoComplete: "off",
						placeholder: "14 رقماً",
						className: "mt-2 w-full rounded-xl border border-line bg-panel-2 px-3 py-3 text-lg tracking-wider text-ink outline-none focus-visible:border-accent"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						className: "mt-3 w-full",
						children: "اشحن الفرنك"
					}),
					message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: cn("mt-3 text-sm", ok ? "text-ink" : "text-accent"),
						children: message
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-6 mb-2 text-sm font-bold text-muted",
				children: "الحركة"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-col gap-2",
				children: ledger.map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center justify-between rounded-xl border border-line bg-panel px-3 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-sm font-bold",
						children: entry.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted tabular-nums",
						children: clock(entry.at)
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Franc, {
						value: entry.delta,
						signed: true,
						className: cn("font-bold", entry.delta < 0 && "text-muted")
					})]
				}, entry.id))
			})
		]
	});
}
//#endregion
export { WalletPage as component };
