import { C as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { S as cn, d as balanceOf, f as useMj, i as Avatar, l as Page, m as COUNTRIES, o as Button, p as AGENCIES, s as Franc, y as countryName } from "./router-DYxSR_8k.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/me-DM0tFZkz.js
var import_jsx_runtime = require_jsx_runtime();
function MePage() {
	const profile = useMj((state) => state.profile);
	const setProfile = useMj((state) => state.setProfile);
	const joinAgency = useMj((state) => state.joinAgency);
	const resetCards = useMj((state) => state.resetCards);
	const giftsSent = useMj((state) => state.giftsSent);
	const balance = useMj((state) => balanceOf(state.ledger));
	const rooms = useMj((state) => state.rooms.filter((room) => room.id.startsWith("user-")));
	const agency = AGENCIES.find((item) => item.id === profile.agencyId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
		title: "أنا",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-5 flex items-center gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
					personId: "me",
					size: "lg"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-lg font-extrabold",
						children: profile.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: countryName(profile.country)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm",
						children: ["الرصيد ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Franc, {
							value: balance,
							className: "font-bold"
						})]
					})
				] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				htmlFor: "display-name",
				className: "text-sm font-bold",
				children: "الاسم في المقاعد"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				id: "display-name",
				value: profile.name,
				maxLength: 24,
				onChange: (event) => setProfile({ name: event.target.value.slice(0, 24) || "ضيف" }),
				className: "mt-1 mb-4 w-full rounded-xl border border-line bg-panel px-3 py-3 outline-none focus-visible:border-accent"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 text-sm font-bold",
				children: "البلد"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-5 grid grid-cols-3 gap-2",
				children: COUNTRIES.map((country) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setProfile({ country: country.id }),
					className: cn("min-h-11 rounded-xl border text-sm font-bold", profile.country === country.id ? "border-accent bg-panel-2" : "border-line bg-panel text-muted"),
					children: country.name
				}, country.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mb-5 rounded-card border border-line bg-panel p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-extrabold",
						children: "الوكالة"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: agency ? `أنت مع ${agency.name}. الهدايا في قاعتها تتقسم 30% للمكتب و70% للمقعد.` : "لسا ما انضممتش. الوكالة تجمع المضيفين وتفتح قاعتها."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 flex flex-col gap-2",
						children: AGENCIES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => joinAgency(profile.agencyId === item.id ? null : item.id),
							className: cn("flex min-h-11 w-full items-center justify-between rounded-xl border px-3 text-sm font-bold", profile.agencyId === item.id ? "border-accent bg-panel-2" : "border-line"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted",
								children: profile.agencyId === item.id ? "مغادرة" : "انضمام"
							})]
						}) }, item.id))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "mb-5 grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-card border border-line bg-panel p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-xs text-muted",
						children: "هدايا بعثتها"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "text-xl font-extrabold tabular-nums",
						children: giftsSent
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-card border border-line bg-panel p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-xs text-muted",
						children: "غرفك الخاصة"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "text-xl font-extrabold tabular-nums",
						children: rooms.length
					})]
				})]
			}),
			rooms.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mb-5 flex flex-col gap-2",
				children: rooms.map((room) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/rooms/$roomId",
					params: { roomId: room.id },
					className: "block rounded-xl border border-line bg-panel px-3 py-3 font-bold",
					children: room.title
				}) }, room.id))
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-card border border-line bg-panel p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-extrabold",
						children: "الصور لاحقاً"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "الأسماء تظهر بالحرف الأول، وبطاقة المشاركة تقدر تتبدل لاحقاً من غير ما يتغير الرصيد أو الغرف أو الوكالات."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "line",
						className: "mt-3",
						onClick: () => resetCards(),
						children: "إعادة تفعيل البطاقات التجريبية"
					})
				]
			})
		]
	});
}
//#endregion
export { MePage as component };
