import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Y as require_react, b as Link, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { S as cn, f as useMj, l as Page, o as Button, p as AGENCIES, y as countryName } from "./router-DYxSR_8k.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/rooms-uqn_frYD.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function RoomsPage() {
	const [tab, setTab] = (0, import_react.useState)("agency");
	const rooms = useMj((state) => state.rooms);
	const createRoom = useMj((state) => state.createRoom);
	const navigate = useNavigate();
	const [title, setTitle] = (0, import_react.useState)("");
	const [lock, setLock] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)("");
	function onCreate() {
		const name = title.trim();
		if (name.length < 2) {
			setError("اكتب اسماً للغرفة.");
			return;
		}
		if (lock && !/^\d{4}$/.test(lock)) {
			setError("الرمز أربعة أرقام، أو اتركه فارغاً.");
			return;
		}
		const id = createRoom(name, lock || void 0);
		navigate({
			to: "/rooms/$roomId",
			params: { roomId: id }
		});
	}
	const privateRooms = rooms.filter((room) => room.kind === "private");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Page, {
		title: "الغرف",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-4 grid grid-cols-2 rounded-xl bg-panel p-1",
			children: [["agency", "وكالات"], ["private", "خاصة"]].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setTab(id),
				className: cn("min-h-11 rounded-lg text-sm font-bold", tab === id ? "bg-panel-2 text-ink" : "text-muted"),
				children: label
			}, id))
		}), tab === "agency" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "flex flex-col gap-3",
			children: AGENCIES.map((agency) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/rooms/$roomId",
				params: { roomId: agency.roomId },
				className: "block rounded-card border border-line bg-panel p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-extrabold",
						children: agency.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-xs text-muted",
						children: [
							agency.city,
							" · ",
							countryName(agency.country)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: agency.blurb
					})
				]
			}) }, agency.id))
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "rounded-card border border-line bg-panel p-4",
				onSubmit: (event) => {
					event.preventDefault();
					onCreate();
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-extrabold",
						children: "غرفة خاصة جديدة"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "افتح قاعة لك. الرمز اختياري ومن أربعة أرقام."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "mt-3 block text-sm font-bold",
						htmlFor: "room-title",
						children: "الاسم"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "room-title",
						value: title,
						onChange: (event) => setTitle(event.target.value),
						maxLength: 40,
						className: "mt-1 w-full rounded-xl border border-line bg-panel-2 px-3 py-3 text-ink outline-none focus-visible:border-accent",
						placeholder: "مثلاً: سهرة الجمعة"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "mt-3 block text-sm font-bold",
						htmlFor: "room-lock",
						children: "رمز الدخول"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						id: "room-lock",
						value: lock,
						onChange: (event) => setLock(event.target.value.replace(/\D/g, "").slice(0, 4)),
						inputMode: "numeric",
						className: "mt-1 w-full rounded-xl border border-line bg-panel-2 px-3 py-3 text-ink outline-none focus-visible:border-accent",
						placeholder: "فارغ يعني مفتوحة"
					}),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-accent",
						children: error
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						className: "mt-4 w-full",
						children: "افتح الغرفة"
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-col gap-3",
				children: privateRooms.map((room) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/rooms/$roomId",
					params: { roomId: room.id },
					className: "flex items-center justify-between rounded-card border border-line bg-panel px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block font-extrabold",
						children: room.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted",
						children: room.lock ? "مقفلة" : "مفتوحة"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-xs text-muted tabular-nums",
						children: [room.listeners, " يسمع"]
					})]
				}) }, room.id))
			})]
		})]
	});
}
//#endregion
export { RoomsPage as component };
