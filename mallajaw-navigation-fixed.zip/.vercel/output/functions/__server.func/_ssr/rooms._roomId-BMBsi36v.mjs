import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Y as require_react, b as Link, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as ChevronRight, a as Send, c as Mic, g as Coffee, h as Crown, i as Sparkles, l as MicOff, m as Flower2, p as Gem } from "../_libs/lucide-react.mjs";
import { S as cn, b as personById, d as balanceOf, f as useMj, h as GIFTS, i as Avatar, n as Route, o as Button, p as AGENCIES, s as Franc, u as displayName, v as clock } from "./router-DYxSR_8k.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/rooms._roomId-BMBsi36v.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var GIFT_ICON = {
	rose: Flower2,
	coffee: Coffee,
	gem: Gem,
	crown: Crown,
	flare: Sparkles
};
function RoomPage() {
	const { roomId } = Route.useParams();
	const room = useMj((state) => state.rooms.find((item) => item.id === roomId));
	const lines = useMj((state) => state.roomLines.filter((item) => item.roomId === roomId));
	const profile = useMj((state) => state.profile);
	const balance = useMj((state) => balanceOf(state.ledger));
	const sit = useMj((state) => state.sit);
	const leaveSeat = useMj((state) => state.leaveSeat);
	const sayInRoom = useMj((state) => state.sayInRoom);
	const giveGift = useMj((state) => state.giveGift);
	const ensureThread = useMj((state) => state.ensureThread);
	const navigate = useNavigate();
	const [unlocked, setUnlocked] = (0, import_react.useState)(!room?.lock);
	const [pin, setPin] = (0, import_react.useState)("");
	const [pinError, setPinError] = (0, import_react.useState)("");
	const [target, setTarget] = (0, import_react.useState)(null);
	const [giftsOpen, setGiftsOpen] = (0, import_react.useState)(false);
	const [note, setNote] = (0, import_react.useState)("");
	const [draft, setDraft] = (0, import_react.useState)("");
	const [micOn, setMicOn] = (0, import_react.useState)(false);
	const [micNote, setMicNote] = (0, import_react.useState)("");
	const [tick, setTick] = (0, import_react.useState)(0);
	const stream = (0, import_react.useRef)(null);
	const log = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		setUnlocked(!room?.lock);
	}, [room?.id, room?.lock]);
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(() => setTick((value) => value + 1), 1600);
		return () => window.clearInterval(id);
	}, []);
	(0, import_react.useEffect)(() => {
		log.current?.scrollTo({ top: log.current.scrollHeight });
	}, [lines.length]);
	(0, import_react.useEffect)(() => () => {
		stream.current?.getTracks().forEach((track) => track.stop());
	}, []);
	const occupied = (0, import_react.useMemo)(() => room ? room.seats.filter((seat) => Boolean(seat)) : [], [room]);
	const speaker = occupied.length ? occupied[tick % occupied.length] : null;
	if (!room) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto w-full max-w-xl px-4 py-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: "الغرفة ما لقيناهاش."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/rooms",
			className: "mt-3 inline-block font-bold text-accent",
			children: "ارجع للغرف"
		})]
	});
	if (room.lock && !unlocked) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex min-h-dvh w-full max-w-xl flex-col px-4 py-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/rooms",
			className: "inline-flex size-11 items-center justify-center",
			"aria-label": "رجوع",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-5" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "m-auto w-full rounded-card border border-line bg-panel p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl font-extrabold",
					children: room.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "غرفة خاصة. اكتب الرمز من أربعة أرقام."
				}),
				room.lock === "2244" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-sm text-muted",
					children: ["رمز التجربة: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("bdi", {
						dir: "ltr",
						className: "font-bold text-ink",
						children: "2244"
					})]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-4",
					onSubmit: (event) => {
						event.preventDefault();
						if (pin === room.lock) {
							setUnlocked(true);
							setPinError("");
						} else setPinError("الرمز غلط.");
					},
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: pin,
							onChange: (event) => setPin(event.target.value.replace(/\D/g, "").slice(0, 4)),
							inputMode: "numeric",
							"aria-label": "رمز الغرفة",
							className: "w-full rounded-xl border border-line bg-panel-2 px-3 py-3 text-center text-2xl tracking-widest text-ink outline-none focus-visible:border-accent"
						}),
						pinError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-accent",
							children: pinError
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							className: "mt-4 w-full",
							children: "ادخل"
						})
					]
				})
			]
		})]
	});
	const agency = AGENCIES.find((item) => item.id === room.agencyId);
	const seated = room.seats.includes("me");
	const targetId = target && room.seats.includes(target) ? target : room.seats.find((seat) => seat && seat !== "me") ?? room.hostId;
	const targetName = displayName(targetId, profile.name);
	async function toggleMic() {
		if (micOn) {
			stream.current?.getTracks().forEach((track) => track.stop());
			stream.current = null;
			setMicOn(false);
			setMicNote("");
			return;
		}
		if (!seated) {
			const index = room?.seats.findIndex((seat) => seat === null) ?? -1;
			if (room && index >= 0) sit(room.id, index);
		}
		try {
			const media = await navigator.mediaDevices.getUserMedia({ audio: true });
			stream.current = media;
			setMicOn(true);
			setMicNote("المايك مفتوح عندك. البث لبقية الناس يجي في نسخة لاحقة.");
		} catch {
			setMicOn(true);
			setMicNote("المتصفح منع المايك. المقعد يتكلم بصرياً فقط.");
		}
	}
	function sendGift(giftId) {
		const gift = GIFTS.find((item) => item.id === giftId);
		if (!gift || !room) return;
		const reason = giveGift(room.id, gift.name, gift.cost, targetName);
		if (reason) {
			setNote(reason);
			return;
		}
		setNote(`وصلت ${gift.name} إلى ${targetName}`);
		setGiftsOpen(false);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex min-h-dvh w-full max-w-3xl flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center gap-2 border-b border-line px-3 py-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/rooms",
						className: "inline-flex size-11 items-center justify-center",
						"aria-label": "رجوع",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "truncate text-base font-extrabold",
							children: room.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "truncate text-xs text-muted",
							children: [
								room.kind === "agency" ? "قاعة وكالة" : "غرفة خاصة",
								" · ",
								room.listeners + (seated ? 1 : 0),
								" يسمع"
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Franc, {
						value: balance,
						className: "text-sm font-bold"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid flex-1 md:grid-cols-[1.1fr_0.9fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "px-4 py-4",
					children: [
						agency ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-4 text-sm text-muted",
							children: agency.blurb
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "grid grid-cols-4 gap-3",
							children: room.seats.map((seat, index) => {
								const name = seat ? displayName(seat, profile.name) : "مقعد";
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									className: "flex w-full flex-col items-center gap-1",
									onClick: () => {
										if (!seat) {
											sit(room.id, index);
											return;
										}
										setTarget(seat);
										setGiftsOpen(false);
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
										personId: seat,
										speaking: Boolean(seat) && (seat === speaker || seat === "me" && micOn)
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "w-full truncate text-center text-xs font-bold",
										children: name.split(" ")[0]
									})]
								}) }, index);
							})
						}),
						target ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 rounded-card border border-line bg-panel p-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-extrabold",
									children: displayName(target, profile.name)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted",
									children: target === "me" ? "هذا مقعدك" : personById(target)?.role ?? ""
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-3 flex flex-wrap gap-2",
									children: target !== "me" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "line",
										onClick: () => {
											const threadId = ensureThread(target);
											navigate({
												to: "/chats/$threadId",
												params: { threadId }
											});
										},
										children: "راسل"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										onClick: () => {
											setGiftsOpen(true);
											setNote("");
										},
										children: "أهدِ"
									})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "line",
										onClick: () => leaveSeat(room.id),
										children: "غادر المقعد"
									})
								})
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-sm text-muted",
							children: "اضغط مقعداً فاضياً لتجلس، أو مضيفاً لتهدي وتراسل."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => void toggleMic(),
								className: cn("inline-flex min-h-11 items-center gap-2 rounded-xl px-4 text-sm font-bold", micOn ? "bg-accent text-ink" : "border border-line bg-panel text-ink"),
								children: [micOn ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, {
									className: "size-4",
									"aria-hidden": "true"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MicOff, {
									className: "size-4",
									"aria-hidden": "true"
								}), micOn ? "المايك مفتوح" : "افتح المايك"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "line",
								onClick: () => setGiftsOpen((value) => !value),
								children: "هدايا"
							})]
						}),
						micNote ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-xs text-muted",
							children: micNote
						}) : null,
						room.kind === "agency" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-xs text-muted",
							children: "في قاعة الوكالة: 30% للمكتب و70% لصاحب المقعد."
						}) : null
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "flex min-h-72 flex-col border-t border-line md:border-s md:border-t-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						ref: log,
						className: "flex max-h-80 flex-1 flex-col gap-2 overflow-y-auto px-4 py-3 md:max-h-none",
						children: lines.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: cn("text-sm", line.kind === "gift" ? "font-bold text-accent" : "text-ink"),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-muted",
									children: [clock(line.at), " · "]
								}),
								line.kind === "chat" ? `${displayName(line.authorId, profile.name).split(" ")[0]}: ` : "",
								line.text
							]
						}, line.id))
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "flex gap-2 border-t border-line px-3 py-3",
						onSubmit: (event) => {
							event.preventDefault();
							sayInRoom(room.id, draft);
							setDraft("");
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: draft,
							onChange: (event) => setDraft(event.target.value),
							maxLength: 180,
							placeholder: "اكتب في القاعة",
							className: "min-h-11 w-full rounded-xl border border-line bg-panel px-3 text-sm outline-none focus-visible:border-accent"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "submit",
							className: "inline-flex size-11 items-center justify-center rounded-xl bg-panel-2",
							"aria-label": "إرسال",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-4" })
						})]
					})]
				})]
			}),
			giftsOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "border-t border-line bg-panel px-4 py-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex w-full max-w-3xl flex-col gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm font-bold",
							children: [
								"هدية إلى ",
								targetName,
								" · الرصيد ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Franc, { value: balance })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "grid grid-cols-2 gap-2 sm:grid-cols-5",
							children: GIFTS.map((gift) => {
								const Icon = GIFT_ICON[gift.id];
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									disabled: balance < gift.cost || targetId === "me",
									onClick: () => sendGift(gift.id),
									className: "flex min-h-20 w-full flex-col items-center justify-center gap-1 rounded-xl border border-line bg-panel-2 text-sm font-bold disabled:opacity-40",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
											className: "size-4",
											"aria-hidden": "true"
										}),
										gift.name,
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Franc, {
											value: gift.cost,
											className: "text-xs text-muted"
										})
									]
								}) }, gift.id);
							})
						}),
						note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-accent",
							children: note
						}) : null
					]
				})
			}) : note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-4 pb-4 text-sm text-accent",
				children: note
			}) : null
		]
	});
}
//#endregion
export { RoomPage as component };
