import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Y as require_react, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as ChevronRight, a as Send } from "../_libs/lucide-react.mjs";
import { S as cn, b as personById, f as useMj, i as Avatar, r as Route$1, v as clock, x as replyFor } from "./router-DYxSR_8k.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/chats._threadId-PRSkXZwf.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ThreadPage() {
	const { threadId } = Route$1.useParams();
	const thread = useMj((state) => state.threads.find((item) => item.id === threadId));
	const messages = useMj((state) => state.messages.filter((item) => item.threadId === threadId));
	const profileName = useMj((state) => state.profile.name);
	const markRead = useMj((state) => state.markRead);
	const sendMessage = useMj((state) => state.sendMessage);
	const receiveMessage = useMj((state) => state.receiveMessage);
	const [draft, setDraft] = (0, import_react.useState)("");
	const scroller = (0, import_react.useRef)(null);
	const timer = (0, import_react.useRef)(null);
	const person = thread ? personById(thread.personId) : void 0;
	(0, import_react.useEffect)(() => {
		markRead(threadId);
	}, [markRead, threadId]);
	(0, import_react.useEffect)(() => {
		scroller.current?.scrollTo({ top: scroller.current.scrollHeight });
	}, [messages.length]);
	(0, import_react.useEffect)(() => () => {
		if (timer.current) window.clearTimeout(timer.current);
	}, []);
	if (!thread || !person) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex w-full max-w-xl flex-1 flex-col px-4 py-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: "هذا الحديث ما لقيناهش."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/chats",
			className: "mt-3 font-bold text-accent",
			children: "ارجع للدردشة"
		})]
	});
	function send() {
		const text = draft.trim();
		if (!text || !person) return;
		setDraft("");
		sendMessage(threadId, text);
		if (timer.current) window.clearTimeout(timer.current);
		timer.current = window.setTimeout(() => {
			receiveMessage(threadId, person.id, replyFor(person.id, text));
			markRead(threadId);
		}, 700);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex h-dvh w-full max-w-xl flex-col md:h-dvh",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center gap-2 border-b border-line px-3 py-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/chats",
						className: "inline-flex size-11 items-center justify-center",
						"aria-label": "رجوع",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
						personId: person.id,
						size: "sm"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "truncate text-base font-extrabold",
							children: person.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "truncate text-xs text-muted",
							children: [
								person.city,
								" · ",
								person.role
							]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				ref: scroller,
				className: "flex flex-1 flex-col gap-2 overflow-y-auto px-4 py-4",
				children: messages.map((message) => {
					const mine = message.authorId === "me";
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: cn("flex w-10/12 flex-col", mine ? "self-end" : "self-start"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: cn("rounded-2xl px-3 py-2 text-sm", mine ? "bg-accent text-ink" : "bg-panel-2 text-ink"),
							children: message.text
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "mt-1 text-xs text-muted tabular-nums",
							children: [
								mine ? profileName : person.name.split(" ")[0],
								" · ",
								clock(message.at)
							]
						})]
					}, message.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex items-center gap-2 border-t border-line px-3 py-3",
				onSubmit: (event) => {
					event.preventDefault();
					send();
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: draft,
					onChange: (event) => setDraft(event.target.value),
					maxLength: 280,
					placeholder: "اكتب رسالة",
					className: "min-h-11 w-full rounded-xl border border-line bg-panel px-3 text-sm text-ink outline-none focus-visible:border-accent"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "inline-flex size-11 shrink-0 items-center justify-center rounded-xl bg-accent text-ink disabled:opacity-40",
					disabled: !draft.trim(),
					"aria-label": "إرسال",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-4" })
				})]
			})
		]
	});
}
//#endregion
export { ThreadPage as component };
