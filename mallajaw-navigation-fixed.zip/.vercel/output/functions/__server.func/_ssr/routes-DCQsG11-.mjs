import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, Y as require_react, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as Lock, o as Search, s as Radio } from "../_libs/lucide-react.mjs";
import { a as BalanceLink, c as Mark, f as useMj, i as Avatar, p as AGENCIES, y as countryName } from "./router-DYxSR_8k.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DCQsG11-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Discover() {
	const rooms = useMj((state) => state.rooms);
	const [query, setQuery] = (0, import_react.useState)("");
	const needle = query.trim();
	const visible = (0, import_react.useMemo)(() => {
		if (!needle) return rooms;
		return rooms.filter((room) => `${room.title} ${room.topic}`.includes(needle));
	}, [rooms, needle]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex w-full max-w-xl flex-1 flex-col px-4 py-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mb-5 flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, { className: "size-10 md:hidden" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-bold tracking-widest text-muted",
						children: "MALLAJAW"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-2xl font-extrabold leading-none",
						children: "ملا جو"
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BalanceLink, {})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mb-5 flex min-h-11 items-center gap-2 rounded-xl border border-line bg-panel px-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
					className: "size-4 text-muted",
					"aria-hidden": "true"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: query,
					onChange: (event) => setQuery(event.target.value),
					placeholder: "ابحث عن غرفة",
					className: "w-full bg-transparent py-3 text-sm text-ink outline-none placeholder:text-muted"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mb-6 min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-3 text-sm font-bold text-muted",
					children: "الوكالات"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mj-scroll flex gap-3 overflow-x-auto",
					children: AGENCIES.map((agency) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/rooms/$roomId",
						params: { roomId: agency.roomId },
						className: "w-44 shrink-0 rounded-card border border-line bg-panel p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-extrabold",
								children: agency.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-xs text-muted",
								children: [
									agency.city,
									" · ",
									countryName(agency.country)
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-3 text-xs text-muted",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("bdi", {
										dir: "ltr",
										className: "font-bold text-ink tabular-nums",
										children: [new Intl.NumberFormat("fr-FR").format(agency.heat), " ف"]
									}),
									" ",
									"هدايا"
								]
							})
						]
					}, agency.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-bold text-muted",
					children: "على الهواء"
				}), visible.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rounded-card border border-line bg-panel px-4 py-6 text-sm text-muted",
					children: "ما لقيناش غرفة بهذا الاسم."
				}) : visible.map((room) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoomRow, { room }, room.id))]
			})
		]
	});
}
function RoomRow({ room }) {
	const occupied = room.seats.filter((seat) => Boolean(seat)).slice(0, 3);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/rooms/$roomId",
		params: { roomId: room.id },
		className: "flex items-center gap-3 rounded-card border border-line bg-panel p-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "flex shrink-0 -space-x-2 space-x-reverse",
				children: occupied.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
					personId: id,
					size: "sm"
				}, id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "min-w-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "truncate font-extrabold",
						children: room.title
					}), room.lock ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, {
						className: "size-3.5 text-muted",
						"aria-label": "مقفلة"
					}) : null]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block truncate text-xs text-muted",
					children: room.topic
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "flex shrink-0 flex-col items-end gap-1 text-xs font-bold",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "inline-flex items-center gap-1 text-accent",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radio, {
						className: "size-3.5",
						"aria-hidden": "true"
					}), room.kind === "agency" ? "وكالة" : "خاصة"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-muted tabular-nums",
					children: [room.listeners, " يسمع"]
				})]
			})
		]
	});
}
//#endregion
export { Discover as component };
