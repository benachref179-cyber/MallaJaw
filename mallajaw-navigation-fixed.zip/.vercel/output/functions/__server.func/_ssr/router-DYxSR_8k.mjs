import { i as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, S as useRouter, Y as require_react, _ as lazyRouteComponent, b as Link, d as Scripts, f as HeadContent, g as Outlet, h as createRouter, p as useRouterState, v as createFileRoute, y as createRootRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as Mic, f as House, n as UserRound, r as TriangleAlert, t as Wallet, u as MessageCircle } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-DYxSR_8k.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* Path-based preview hosts serve the dev server under `/{port_id}/` and strip
* that prefix before forwarding, so SSR sees `/` while the browser URL keeps the
* prefix. TanStack Start resets `basepath` on hydration, so a `rewrite` keeps
* client routing and generated links aligned with the public URL.
*/
var PATH_BASED_PREVIEW_HOSTS = /* @__PURE__ */ new Set([
	"preview.grok.genai.mil",
	"preview.grok.mil",
	"preview.grokgsac.com"
]);
var PORT_ID_PREFIX = /^\/hds-[a-z0-9]+-\d+-[a-z0-9]+(?=\/|$)/i;
function previewPathPrefix(hostname, pathname) {
	if (!PATH_BASED_PREVIEW_HOSTS.has(hostname.toLowerCase())) return void 0;
	return PORT_ID_PREFIX.exec(pathname)?.[0];
}
function prefixRewrite(prefix) {
	return {
		input: ({ url }) => {
			if (url.pathname === prefix) url.pathname = "/";
			else if (url.pathname.startsWith(`${prefix}/`)) url.pathname = url.pathname.slice(prefix.length);
			return url;
		},
		output: ({ url }) => {
			url.pathname = `${prefix}${url.pathname}`;
			return url;
		}
	};
}
function previewPathRewrite() {
	if (typeof window === "undefined") return void 0;
	const prefix = previewPathPrefix(window.location.hostname, window.location.pathname);
	return prefix ? prefixRewrite(prefix) : void 0;
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var COUNTRIES = [
	{
		id: "TN",
		name: "تونس",
		dial: "216"
	},
	{
		id: "DZ",
		name: "الجزائر",
		dial: "213"
	},
	{
		id: "LY",
		name: "ليبيا",
		dial: "218"
	}
];
var OPERATORS = [
	{
		id: "orange",
		name: "أورونج",
		latin: "Orange"
	},
	{
		id: "ooredoo",
		name: "أوريدو",
		latin: "Ooredoo"
	},
	{
		id: "telecom",
		name: "تيليكوم",
		latin: "Telecom"
	}
];
var GIFTS = [
	{
		id: "rose",
		name: "وردة",
		cost: 30
	},
	{
		id: "coffee",
		name: "قهوة",
		cost: 80
	},
	{
		id: "gem",
		name: "جوهرة",
		cost: 200
	},
	{
		id: "crown",
		name: "تاج",
		cost: 500
	},
	{
		id: "flare",
		name: "شعلة",
		cost: 1200
	}
];
/** Demo scratch cards only. They never leave the device and do not debit a real line. */
var SCRATCH_CARDS = [
	{
		code: "21614000000015",
		country: "TN",
		operator: "orange",
		face: "5 د.ت",
		francs: 500
	},
	{
		code: "21614000000020",
		country: "TN",
		operator: "orange",
		face: "10 د.ت",
		francs: 1100
	},
	{
		code: "21615000000015",
		country: "TN",
		operator: "ooredoo",
		face: "5 د.ت",
		francs: 500
	},
	{
		code: "21615000000040",
		country: "TN",
		operator: "ooredoo",
		face: "20 د.ت",
		francs: 2400
	},
	{
		code: "21616000000011",
		country: "TN",
		operator: "telecom",
		face: "1 د.ت",
		francs: 100
	},
	{
		code: "21616000000020",
		country: "TN",
		operator: "telecom",
		face: "10 د.ت",
		francs: 1100
	},
	{
		code: "21314000000500",
		country: "DZ",
		operator: "orange",
		face: "500 د.ج",
		francs: 400
	},
	{
		code: "21314000001000",
		country: "DZ",
		operator: "orange",
		face: "1000 د.ج",
		francs: 900
	},
	{
		code: "21315000000200",
		country: "DZ",
		operator: "ooredoo",
		face: "200 د.ج",
		francs: 160
	},
	{
		code: "21315000001000",
		country: "DZ",
		operator: "ooredoo",
		face: "1000 د.ج",
		francs: 900
	},
	{
		code: "21316000000500",
		country: "DZ",
		operator: "telecom",
		face: "500 د.ج",
		francs: 400
	},
	{
		code: "21316000002000",
		country: "DZ",
		operator: "telecom",
		face: "2000 د.ج",
		francs: 2e3
	},
	{
		code: "21814000000005",
		country: "LY",
		operator: "orange",
		face: "5 د.ل",
		francs: 900
	},
	{
		code: "21814000000010",
		country: "LY",
		operator: "orange",
		face: "10 د.ل",
		francs: 1900
	},
	{
		code: "21815000000005",
		country: "LY",
		operator: "ooredoo",
		face: "5 د.ل",
		francs: 900
	},
	{
		code: "21815000000020",
		country: "LY",
		operator: "ooredoo",
		face: "20 د.ل",
		francs: 4e3
	},
	{
		code: "21816000000010",
		country: "LY",
		operator: "telecom",
		face: "10 د.ل",
		francs: 1900
	},
	{
		code: "21816000000020",
		country: "LY",
		operator: "telecom",
		face: "20 د.ل",
		francs: 4e3
	}
];
var PEOPLE = [
	{
		id: "yasmine",
		name: "ياسمين بن يوسف",
		city: "تونس",
		country: "TN",
		role: "رئيسة القاعة"
	},
	{
		id: "mehdi",
		name: "مهدي الشريف",
		city: "صفاقس",
		country: "TN",
		role: "مضيف"
	},
	{
		id: "nour",
		name: "نور الهدى عياد",
		city: "تونس",
		country: "TN",
		role: "مضيفة"
	},
	{
		id: "fedi",
		name: "فادي الجلاصي",
		city: "الحمامات",
		country: "TN",
		role: "صاحب غرفة"
	},
	{
		id: "lina",
		name: "لينا بوعلام",
		city: "الجزائر",
		country: "DZ",
		role: "رئيسة وكالة"
	},
	{
		id: "amine",
		name: "أمين قادري",
		city: "وهران",
		country: "DZ",
		role: "مضيف"
	},
	{
		id: "karim",
		name: "كريم بلقاسم",
		city: "قسنطينة",
		country: "DZ",
		role: "مضيف"
	},
	{
		id: "sara",
		name: "سارة المبروك",
		city: "طرابلس",
		country: "LY",
		role: "رئيسة وكالة"
	},
	{
		id: "omar",
		name: "عمر التومي",
		city: "بنغازي",
		country: "LY",
		role: "مضيف"
	},
	{
		id: "huda",
		name: "هدى الزنتاني",
		city: "مصراتة",
		country: "LY",
		role: "مضيفة"
	}
];
var AGENCIES = [
	{
		id: "layali",
		name: "وكالة ليالي تونس",
		city: "تونس",
		country: "TN",
		blurb: "قاعة ليلية هادئة. الورد أكثر هدية، والمقاعد الثمانية ما تمتليش إلا بعد منتصف الليل.",
		hostIds: [
			"yasmine",
			"mehdi",
			"nour"
		],
		roomId: "r-layali",
		heat: 18400
	},
	{
		id: "nojoom",
		name: "وكالة نجوم الجزائر",
		city: "الجزائر",
		country: "DZ",
		blurb: "صوت عالي ومقاعد للوكالات. كل هدية تتقسم: الوكالة تأخذ نصيبها والمضيف يأخذ الباقي.",
		hostIds: [
			"lina",
			"amine",
			"karim"
		],
		roomId: "r-nojoom",
		heat: 12650
	},
	{
		id: "darb",
		name: "وكالة درب ليبيا",
		city: "طرابلس",
		country: "LY",
		blurb: "سهرة قريبة وكلام واضح. الفرنك هنا يمشي على المايك مباشرة.",
		hostIds: [
			"sara",
			"omar",
			"huda"
		],
		roomId: "r-darb",
		heat: 9800
	}
];
var empty = () => [
	null,
	null,
	null,
	null,
	null,
	null,
	null,
	null
];
function seats(ids) {
	const next = empty();
	ids.forEach((id, index) => {
		next[index] = id;
	});
	return next;
}
var ROOMS = [
	{
		id: "r-layali",
		kind: "agency",
		title: "ليالي تونس",
		topic: "سهرة هادية · مقعد للضيوف",
		agencyId: "layali",
		hostId: "yasmine",
		seats: seats([
			"yasmine",
			"mehdi",
			"nour",
			null,
			null,
			null,
			null,
			null
		]),
		listeners: 128
	},
	{
		id: "r-nojoom",
		kind: "agency",
		title: "نجوم الجزائر",
		topic: "قاعة الوكالة · هدايا مفتوحة",
		agencyId: "nojoom",
		hostId: "lina",
		seats: seats([
			"lina",
			"amine",
			null,
			"karim",
			null,
			null,
			null,
			null
		]),
		listeners: 86
	},
	{
		id: "r-darb",
		kind: "agency",
		title: "درب ليبيا",
		topic: "مايك قريب · كلام خفيف",
		agencyId: "darb",
		hostId: "sara",
		seats: seats([
			"sara",
			null,
			"omar",
			"huda",
			null,
			null,
			null,
			null
		]),
		listeners: 64
	},
	{
		id: "r-friends",
		kind: "private",
		title: "سهرة الأصدقاء",
		topic: "غرفة بلا رمز",
		hostId: "fedi",
		seats: seats([
			"fedi",
			null,
			null,
			null,
			null,
			null,
			null,
			null
		]),
		listeners: 7
	},
	{
		id: "r-family",
		kind: "private",
		title: "مجلس العائلة",
		topic: "غرفة مقفلة",
		hostId: "nour",
		seats: seats([
			"nour",
			"huda",
			null,
			null,
			null,
			null,
			null,
			null
		]),
		listeners: 4,
		lock: "2244"
	}
];
var T = Date.UTC(2026, 9, 11, 20, 0, 0);
var THREADS = [
	{
		id: "t-yasmine",
		personId: "yasmine",
		unread: 0
	},
	{
		id: "t-lina",
		personId: "lina",
		unread: 1
	},
	{
		id: "t-sara",
		personId: "sara",
		unread: 0
	},
	{
		id: "t-fedi",
		personId: "fedi",
		unread: 1
	}
];
var MESSAGES = [
	{
		id: "m1",
		threadId: "t-yasmine",
		authorId: "yasmine",
		text: "أهلا. سهرة ليالي تونس مفتوحة. تدخل المايك؟",
		at: T - 48e5
	},
	{
		id: "m2",
		threadId: "t-yasmine",
		authorId: "me",
		text: "ندخل بعد شوية. خلّيلي مقعد قدام.",
		at: T - 42e5
	},
	{
		id: "m3",
		threadId: "t-yasmine",
		authorId: "yasmine",
		text: "المقعد الرابع ليك. الورد الليلة بثلاثين فرنك.",
		at: T - 384e4
	},
	{
		id: "m4",
		threadId: "t-lina",
		authorId: "lina",
		text: "الوكالة محتاجة صوت من تونس. تحب تنضم لنجوم الجزائر؟",
		at: T - 24e5
	},
	{
		id: "m5",
		threadId: "t-sara",
		authorId: "sara",
		text: "بعثت لك جو الغرفة. درب ليبيا عامرة شوية.",
		at: T - 84e5
	},
	{
		id: "m6",
		threadId: "t-sara",
		authorId: "me",
		text: "واصل. نشحن فرنكات وندخل.",
		at: T - 72e5
	},
	{
		id: "m7",
		threadId: "t-fedi",
		authorId: "fedi",
		text: "الغرفة الخاصة بلا رمز الليلة. اجي كي تحب.",
		at: T - 15e5
	}
];
var ROOM_LINES = [
	{
		id: "rl1",
		roomId: "r-layali",
		authorId: "system",
		text: "ياسمين فتحت قاعة الوكالة",
		at: T - 18e5,
		kind: "system"
	},
	{
		id: "rl2",
		roomId: "r-layali",
		authorId: "yasmine",
		text: "المايك مفتوح للضيوف. تفضلوا.",
		at: T - 132e4,
		kind: "chat"
	},
	{
		id: "rl3",
		roomId: "r-layali",
		authorId: "mehdi",
		text: "أهدى وردة إلى ياسمين",
		at: T - 96e4,
		kind: "gift"
	},
	{
		id: "rl4",
		roomId: "r-nojoom",
		authorId: "lina",
		text: "مقاعد الوكالة جاهزة.",
		at: T - 108e4,
		kind: "chat"
	},
	{
		id: "rl5",
		roomId: "r-darb",
		authorId: "sara",
		text: "من طرابلس، سهرة خفيفة.",
		at: T - 72e4,
		kind: "chat"
	},
	{
		id: "rl6",
		roomId: "r-friends",
		authorId: "fedi",
		text: "ادخلوا بلا رمز.",
		at: T - 54e4,
		kind: "chat"
	},
	{
		id: "rl7",
		roomId: "r-family",
		authorId: "nour",
		text: "الباب مقفول على الأربعة.",
		at: T - 3e6,
		kind: "chat"
	}
];
var WELCOME_LEDGER = [{
	id: "welcome",
	at: T - 12e6,
	label: "رصيد ترحيبي",
	delta: 860
}];
var REPLIES = {
	yasmine: [
		"حاضر، المقعد ليك كي تدخل القاعة.",
		"الورد يوصلني مباشرة. يعطيك الصحة.",
		"السهرة لسا طويلة، ما تستعجلش."
	],
	lina: [
		"إذا انضممت للوكالة، مقاعدك تتحسب مع النجوم.",
		"الهدايا هنا تتقسم ٣٠ للمكتب و٧٠ ليك إذا جلست.",
		"اكتبلي من أي مدينة في تونس."
	],
	sara: [
		"درب ليبيا مفتوح. ادخل من الغرف.",
		"الشحن ببطاقة ليبيا يمشي في المحفظة التجريبية.",
		"كي تيجي، سلم على عمر وهدى."
	],
	fedi: [
		"الغرفة بلا رمز، اضغط وادخل.",
		"إذا تحب تقفل غرفتك، حط أربعة أرقام وأنت تنشئها.",
		"نسمعك كي تفتح المايك المحلي."
	],
	mehdi: ["أنا على المقعد الثاني. ارسل وردة لو تحب.", "صفاقس في الدار الليلة."],
	nour: ["مجلس العائلة رمزه ٢٢٤٤.", "المقعد هادئ، تكلم براحتك."],
	amine: ["وهران حاضرة. القاعة لسا فيها مكان.", "التاج يبان على الشاشة طول."],
	karim: ["قسنطينة تسلم.", "ادخل مقعد فاضي وما تكثرش الهدايا دفعة واحدة."],
	omar: ["بنغازي على الخط.", "القهوة بثمانين فرنك، خفيفة ولطيفة."],
	huda: ["مصراتة معاكم.", "إذا الوكالة عجبتك، انضم من صفحة أنا."]
};
var FALLBACK = [
	"وصلت الرسالة.",
	"نكملوا في الغرفة أحسن.",
	"الفرنك في المحفظة إذا تحب تشحن قبل ما تدخل."
];
function replyFor(personId, text) {
	const list = REPLIES[personId] ?? FALLBACK;
	return list[Math.abs(text.trim().length) % list.length] ?? list[0] ?? "وصلت.";
}
function personById(id) {
	return PEOPLE.find((person) => person.id === id);
}
function countryName(id) {
	return COUNTRIES.find((country) => country.id === id)?.name ?? id;
}
function clock(at) {
	return new Intl.DateTimeFormat("fr-FR", {
		hour: "2-digit",
		minute: "2-digit",
		timeZone: "Africa/Tunis"
	}).format(at);
}
var memoryStorage = {
	getItem: () => null,
	setItem: () => void 0,
	removeItem: () => void 0
};
function uid(prefix) {
	return `${prefix}-${crypto.randomUUID()}`;
}
var initial = {
	profile: {
		name: "ضيف ملا جو",
		country: "TN",
		agencyId: null
	},
	rooms: ROOMS,
	threads: THREADS,
	messages: MESSAGES,
	roomLines: ROOM_LINES,
	ledger: WELCOME_LEDGER,
	usedCodes: [],
	giftsSent: 0
};
function balanceOf(ledger) {
	return ledger.reduce((sum, entry) => sum + entry.delta, 0);
}
var useMj = create()(persist((set, get) => ({
	...initial,
	setProfile: (patch) => set((state) => ({ profile: {
		...state.profile,
		...patch
	} })),
	joinAgency: (agencyId) => set((state) => ({ profile: {
		...state.profile,
		agencyId
	} })),
	markRead: (threadId) => set((state) => ({ threads: state.threads.map((thread) => thread.id === threadId ? {
		...thread,
		unread: 0
	} : thread) })),
	ensureThread: (personId) => {
		const found = get().threads.find((thread) => thread.personId === personId);
		if (found) return found.id;
		const id = uid("t");
		set((state) => ({ threads: [{
			id,
			personId,
			unread: 0
		}, ...state.threads] }));
		return id;
	},
	sendMessage: (threadId, text) => {
		const clean = text.trim();
		if (!clean) return;
		const message = {
			id: uid("m"),
			threadId,
			authorId: "me",
			text: clean.slice(0, 280),
			at: Date.now()
		};
		set((state) => ({ messages: [...state.messages, message] }));
	},
	receiveMessage: (threadId, authorId, text) => {
		const message = {
			id: uid("m"),
			threadId,
			authorId,
			text,
			at: Date.now()
		};
		set((state) => ({
			messages: [...state.messages, message],
			threads: state.threads.map((thread) => thread.id === threadId ? {
				...thread,
				unread: thread.unread + 1
			} : thread)
		}));
	},
	createRoom: (title, lock) => {
		const id = uid("user");
		const room = {
			id,
			kind: "private",
			title: title.slice(0, 40),
			topic: lock ? "غرفة خاصة مقفلة" : "غرفة خاصة مفتوحة",
			hostId: "me",
			seats: [
				"me",
				null,
				null,
				null,
				null,
				null,
				null,
				null
			],
			listeners: 1,
			lock: lock || void 0
		};
		const line = {
			id: uid("rl"),
			roomId: id,
			authorId: "system",
			text: "أنت فتحت الغرفة",
			at: Date.now(),
			kind: "system"
		};
		set((state) => ({
			rooms: [room, ...state.rooms],
			roomLines: [...state.roomLines, line]
		}));
		return id;
	},
	sit: (roomId, index) => set((state) => ({ rooms: state.rooms.map((room) => {
		if (room.id !== roomId) return room;
		if (room.seats[index] && room.seats[index] !== "me") return room;
		const seats = room.seats.map((seat) => seat === "me" ? null : seat);
		seats[index] = "me";
		return {
			...room,
			seats
		};
	}) })),
	leaveSeat: (roomId) => set((state) => ({ rooms: state.rooms.map((room) => room.id === roomId ? {
		...room,
		seats: room.seats.map((seat) => seat === "me" ? null : seat)
	} : room) })),
	sayInRoom: (roomId, text) => {
		const clean = text.trim();
		if (!clean) return;
		const line = {
			id: uid("rl"),
			roomId,
			authorId: "me",
			text: clean.slice(0, 180),
			at: Date.now(),
			kind: "chat"
		};
		set((state) => ({ roomLines: [...state.roomLines, line] }));
	},
	giveGift: (roomId, giftName, cost, targetName) => {
		if (balanceOf(get().ledger) < cost) return "رصيد الفرنك ما يكفيش.";
		const line = {
			id: uid("rl"),
			roomId,
			authorId: "me",
			text: `أهدى ${giftName} إلى ${targetName}`,
			at: Date.now(),
			kind: "gift"
		};
		const entry = {
			id: uid("lg"),
			at: Date.now(),
			label: `${giftName} إلى ${targetName}`,
			delta: -cost
		};
		set((state) => ({
			roomLines: [...state.roomLines, line],
			ledger: [entry, ...state.ledger],
			giftsSent: state.giftsSent + 1
		}));
		return null;
	},
	redeem: (code) => {
		const digits = code.replace(/\D/g, "");
		const card = SCRATCH_CARDS.find((item) => item.code === digits);
		if (!card) return {
			ok: false,
			reason: "الرمز ما عندوش بطاقة تجريبية. اختار واحدة من القائمة."
		};
		if (get().usedCodes.includes(digits)) return {
			ok: false,
			reason: "هذه البطاقة استُعملت. فعّلها من جديد من صفحة أنا."
		};
		const entry = {
			id: uid("lg"),
			at: Date.now(),
			label: `شحن ${card.face}`,
			delta: card.francs
		};
		set((state) => ({
			usedCodes: [...state.usedCodes, digits],
			ledger: [entry, ...state.ledger]
		}));
		return {
			ok: true,
			francs: card.francs
		};
	},
	resetCards: () => set({ usedCodes: [] })
}), {
	name: "mallajaw-v1",
	skipHydration: true,
	storage: createJSONStorage(() => typeof window === "undefined" ? memoryStorage : localStorage),
	partialize: (state) => ({
		profile: state.profile,
		rooms: state.rooms,
		threads: state.threads,
		messages: state.messages,
		roomLines: state.roomLines,
		ledger: state.ledger,
		usedCodes: state.usedCodes,
		giftsSent: state.giftsSent
	})
}));
function Mark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className,
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				width: "32",
				height: "32",
				rx: "8",
				className: "fill-panel-2"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "6.5",
				y: "12",
				width: "3.4",
				height: "8",
				rx: "1.7",
				className: "fill-accent"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "14.3",
				y: "7",
				width: "3.4",
				height: "18",
				rx: "1.7",
				className: "fill-ink"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "22.1",
				y: "10.5",
				width: "3.4",
				height: "11",
				rx: "1.7",
				className: "fill-accent"
			})
		]
	});
}
function Franc({ value, signed = false, className }) {
	const abs = new Intl.NumberFormat("fr-FR").format(Math.abs(value));
	const sign = !signed || value === 0 ? "" : value > 0 ? "+" : "−";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("bdi", {
		dir: "ltr",
		className: cn("tabular-nums", className),
		children: [
			sign,
			abs,
			" ف"
		]
	});
}
function Avatar({ personId, speaking = false, size = "md" }) {
	const profile = useMj((state) => state.profile);
	const box = size === "lg" ? "size-20 text-2xl" : size === "sm" ? "size-9 text-xs" : "size-14 text-lg";
	if (!personId) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("inline-flex items-center justify-center rounded-full border border-dashed border-line text-muted", box) });
	const person = personId === "me" ? null : personById(personId);
	const letter = (personId === "me" ? profile.name : person?.name ?? "؟").trim().slice(0, 1) || "؟";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center justify-center rounded-full border bg-panel-2 font-bold text-ink", speaking ? "border-accent mj-speak" : "border-line", box),
		"aria-hidden": "true",
		children: letter
	});
}
function displayName(personId, mine) {
	if (personId === "me") return mine;
	if (personId === "system") return "القاعة";
	return personById(personId)?.name ?? "مجهول";
}
function Button({ variant = "solid", className, type = "button", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		className: cn("inline-flex min-h-11 items-center justify-center gap-2 rounded-xl px-4 text-sm font-bold", "disabled:cursor-not-allowed disabled:opacity-40", "focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent", variant === "solid" && "bg-accent text-ink", variant === "line" && "border border-line bg-panel text-ink", variant === "ghost" && "bg-transparent text-ink", className),
		...props
	});
}
function Page({ title, action, children, wide = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("mx-auto flex w-full flex-1 flex-col px-4 py-4", wide ? "max-w-3xl" : "max-w-xl"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "mb-4 flex items-center justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-extrabold",
				children: title
			}), action]
		}), children]
	});
}
function BalanceLink() {
	const value = useMj((state) => state.ledger).reduce((sum, entry) => sum + entry.delta, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/wallet",
		className: "inline-flex min-h-11 items-center rounded-full bg-accent px-3 text-sm font-bold text-ink focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Franc, { value })
	});
}
var TABS = [
	{
		to: "/",
		label: "اكتشف",
		icon: House
	},
	{
		to: "/rooms",
		label: "الغرف",
		icon: Mic
	},
	{
		to: "/chats",
		label: "الدردشة",
		icon: MessageCircle
	},
	{
		to: "/wallet",
		label: "المحفظة",
		icon: Wallet
	},
	{
		to: "/me",
		label: "أنا",
		icon: UserRound
	}
];
function isOn(pathname, to) {
	if (to === "/") return pathname === "/";
	return pathname === to || pathname.startsWith(`${to}/`);
}
function AppShell({ children }) {
	const pathname = useRouterState({ select: (state) => state.location.pathname });
	const immersive = /^\/(rooms|chats)\/[^/]+/.test(pathname);
	const unread = useMj((state) => state.threads.reduce((sum, thread) => sum + thread.unread, 0));
	const balance = useMj((state) => balanceOf(state.ledger));
	(0, import_react.useEffect)(() => {
		useMj.persist.rehydrate();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-dvh bg-canvas text-ink",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex min-h-dvh w-full max-w-6xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "sticky top-0 hidden h-dvh w-60 shrink-0 flex-col border-e border-line px-4 py-6 md:flex",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/",
						className: "mb-8 flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, { className: "size-10" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-lg font-extrabold leading-none",
							children: "ملا جو"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs tracking-widest text-muted",
							children: "MALLAJAW"
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "flex flex-1 flex-col gap-1",
						"aria-label": "التنقل",
						children: TABS.map((tab) => {
							const Icon = tab.icon;
							const on = isOn(pathname, tab.to);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: tab.to,
								"aria-current": on ? "page" : void 0,
								className: cn("flex min-h-11 items-center gap-3 rounded-xl px-3 text-sm font-bold", on ? "bg-panel-2 text-ink" : "text-muted"),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
										className: "size-5",
										"aria-hidden": "true"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "flex-1",
										children: tab.label
									}),
									tab.to === "/chats" && unread > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "rounded-full bg-accent px-2 text-xs text-ink",
										children: unread
									}) : null
								]
							}, tab.to);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							"الرصيد",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("bdi", {
								dir: "ltr",
								className: "font-bold text-ink tabular-nums",
								children: [new Intl.NumberFormat("fr-FR").format(balance), " ف"]
							})
						]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-w-0 flex-1 flex-col md:border-s md:border-line",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: cn("flex flex-1 flex-col", immersive ? "" : "pb-24 md:pb-6"),
					children
				}), immersive ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "mj-tabbar fixed inset-x-0 bottom-0 z-20 border-t border-line bg-canvas md:hidden",
					"aria-label": "التنقل",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mx-auto grid max-w-xl grid-cols-5",
						children: TABS.map((tab) => {
							const Icon = tab.icon;
							const on = isOn(pathname, tab.to);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: tab.to,
								"aria-current": on ? "page" : void 0,
								className: cn("flex min-h-16 flex-col items-center justify-center gap-1 text-xs font-bold", on ? "text-ink" : "text-muted"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "relative",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
										className: "size-5",
										"aria-hidden": "true"
									}), tab.to === "/chats" && unread > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute -top-1 -start-1 size-2 rounded-full bg-accent" }) : null]
								}), tab.label]
							}) }, tab.to);
						})
					})
				})]
			})]
		})
	});
}
var styles_default = "/assets/styles-zy978e97.css";
var Route$7 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "ملا جو · MallaJaw" },
			{
				name: "description",
				content: "دردشة، غرف صوت خاصة، وقاعات وكالات. العملة فرنك، والشحن التجريبي ببطاقات تونس والجزائر وليبيا."
			},
			{
				name: "theme-color",
				content: "#000000"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "ar",
		dir: "rtl",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	})
});
var $$splitComponentImporter$6 = () => import("./routes-DCQsG11-.mjs");
var Route$6 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./chats-DCDqlZ8e.mjs");
var Route$5 = createFileRoute("/chats")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./me-DM0tFZkz.mjs");
var Route$4 = createFileRoute("/me")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./rooms-uqn_frYD.mjs");
var Route$3 = createFileRoute("/rooms")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./wallet-Brux8vpU.mjs");
var Route$2 = createFileRoute("/wallet")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./chats._threadId-PRSkXZwf.mjs");
var Route$1 = createFileRoute("/chats/$threadId")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./rooms._roomId-BMBsi36v.mjs");
var Route = createFileRoute("/rooms/$roomId")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var IndexRoute = Route$6.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$7
});
var ChatsRoute = Route$5.update({
	id: "/chats",
	path: "/chats",
	getParentRoute: () => Route$7
});
var MeRoute = Route$4.update({
	id: "/me",
	path: "/me",
	getParentRoute: () => Route$7
});
var RoomsRoute = Route$3.update({
	id: "/rooms",
	path: "/rooms",
	getParentRoute: () => Route$7
});
var WalletRoute = Route$2.update({
	id: "/wallet",
	path: "/wallet",
	getParentRoute: () => Route$7
});
var ChatsThreadIdRoute = Route$1.update({
	id: "/$threadId",
	path: "/$threadId",
	getParentRoute: () => ChatsRoute
});
var RoomsRoomIdRoute = Route.update({
	id: "/$roomId",
	path: "/$roomId",
	getParentRoute: () => RoomsRoute
});
var ChatsRouteChildren = { ChatsThreadIdRoute };
var ChatsRouteWithChildren = ChatsRoute._addFileChildren(ChatsRouteChildren);
var RoomsRouteChildren = { RoomsRoomIdRoute };
var rootRouteChildren = {
	IndexRoute,
	ChatsRoute: ChatsRouteWithChildren,
	MeRoute,
	RoomsRoute: RoomsRoute._addFileChildren(RoomsRouteChildren),
	WalletRoute
};
var routeTree = Route$7._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		rewrite: previewPathRewrite(),
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { cn as S, SCRATCH_CARDS as _, BalanceLink as a, personById as b, Mark as c, balanceOf as d, useMj as f, OPERATORS as g, GIFTS as h, Avatar as i, Page as l, COUNTRIES as m, Route as n, Button as o, AGENCIES as p, Route$1 as r, Franc as s, router_exports as t, displayName as u, clock as v, replyFor as x, countryName as y };
