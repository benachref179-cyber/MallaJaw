import { C as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { b as personById, f as useMj, i as Avatar, l as Page, v as clock } from "./router-DYxSR_8k.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/chats-DCDqlZ8e.js
var import_jsx_runtime = require_jsx_runtime();
function ChatsPage() {
	const threads = useMj((state) => state.threads);
	const messages = useMj((state) => state.messages);
	const ordered = [...threads].sort((a, b) => {
		const lastA = messages.filter((message) => message.threadId === a.id).at(-1)?.at ?? 0;
		return (messages.filter((message) => message.threadId === b.id).at(-1)?.at ?? 0) - lastA;
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, {
		title: "الدردشة",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "flex flex-col gap-2",
			children: ordered.map((thread) => {
				const person = personById(thread.personId);
				const last = messages.filter((message) => message.threadId === thread.id).at(-1);
				if (!person) return null;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/chats/$threadId",
					params: { threadId: thread.id },
					className: "flex items-center gap-3 rounded-card border border-line bg-panel p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
							personId: person.id,
							size: "md"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "truncate font-extrabold",
									children: person.name
								}), last ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs text-muted tabular-nums",
									children: clock(last.at)
								}) : null]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block truncate text-sm text-muted",
								children: last?.text ?? "ابدأ الحديث"
							})]
						}),
						thread.unread > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "inline-flex size-6 items-center justify-center rounded-full bg-accent text-xs font-bold text-ink",
							children: thread.unread
						}) : null
					]
				}) }, thread.id);
			})
		})
	});
}
//#endregion
export { ChatsPage as component };
