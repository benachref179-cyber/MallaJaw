//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CwdHrPKB.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/chats",
			"/me",
			"/rooms",
			"/wallet"
		],
		preloads: [
			"/assets/index-CvoIFfFp.js",
			"/assets/ui-DDA95b_R.js",
			"/assets/preload-helper-B24u6OYd.js",
			"/assets/createLucideIcon-BXHmP6Mk.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CvoIFfFp.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DZ0e7xK7.js"]
	},
	"/chats": {
		filePath: "/workspace/src/routes/chats.tsx",
		children: ["/chats/$threadId"],
		preloads: ["/assets/chats-CEeOq1cW.js"]
	},
	"/me": {
		filePath: "/workspace/src/routes/me.tsx",
		children: void 0,
		preloads: ["/assets/me-BKZRfYZj.js"]
	},
	"/rooms": {
		filePath: "/workspace/src/routes/rooms.tsx",
		children: ["/rooms/$roomId"],
		preloads: ["/assets/rooms-BZKX7k8z.js", "/assets/useNavigate-CpmaV4Me.js"]
	},
	"/wallet": {
		filePath: "/workspace/src/routes/wallet.tsx",
		children: void 0,
		preloads: ["/assets/wallet-BQD8QNw6.js"]
	},
	"/chats/$threadId": {
		filePath: "/workspace/src/routes/chats.$threadId.tsx",
		children: void 0,
		preloads: ["/assets/chats._threadId-Cqm4PHT3.js", "/assets/send-BHYNRgDb.js"]
	},
	"/rooms/$roomId": {
		filePath: "/workspace/src/routes/rooms.$roomId.tsx",
		children: void 0,
		preloads: ["/assets/rooms._roomId-CB3lT-qm.js", "/assets/send-BHYNRgDb.js"]
	}
} });
//#endregion
export { tsrStartManifest };
